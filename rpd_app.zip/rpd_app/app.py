from flask import Flask

app = Flask(__name__)

import controllers.upload
import controllers.rpd_generate
import controllers.generated_files

# if __name__ == '__main__':
#     app.run(debug=True)
