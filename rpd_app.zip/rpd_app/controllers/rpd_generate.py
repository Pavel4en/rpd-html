from app import app
from docx import Document
import base64
from docxtpl import DocxTemplate
import os
import io
from flask import render_template, request, jsonify, Response, send_file, send_from_directory
from pymongo import MongoClient


client = MongoClient("mongodb+srv://4enpavel:NdEKoRqD6xlQGHUB@planeducation.jaybzzr.mongodb.net/test?retryWrites=true&w=majority")
db = client.test
generated_files = []

@app.route('/years')
def years():
    # Получение списка уникальных годов из базы данных
    years = db.disciplines.distinct('year_education')
    
    # Передача списка в шаблон страницы
    return render_template('rpd_generate.html', years=years)

@app.route('/get_educational_programs', methods=['POST'])
def get_educational_programs():
    year = request.form['year']
    programs = db.disciplines.distinct("name_education", {"year_education": year})
    programs.insert(0, "")
    return {'programs': programs}

@app.route('/get_directions', methods=['POST'])
def get_directions():
    program = request.form['program']
    directions = db.disciplines.distinct("name_direction", {"name_education": program})
    directions.insert(0, "")
    return {'directions': directions}

@app.route('/get_disciplines', methods=['POST'])
def get_disciplines():
    direction = request.form['direction']
    disciplines = db.disciplines.distinct("discipline_name", {"name_direction": direction})
    disciplines.insert(0, "")
    department = db.disciplines.find_one({"name_direction": direction})['department_name']
    form_education = db.disciplines.find_one({"name_direction": direction})['form_educ']
    titul_name = db.disciplines.find_one({"name_direction": direction})['titul_name']
    return {'disciplines': disciplines, 'department': department, 'form_education' : form_education, 'titul_name':titul_name}


@app.route('/get_department', methods=['POST'])
def get_department():
    discipline = request.form['discipline']
    department = db.disciplines.find_one({"discipline_name": discipline})['department_name']
    return {'department': department}

@app.route('/get_form_education', methods=['POST'])
def get_form_education():
    discipline = request.form['discipline']
    form_education = db.disciplines.find_one({"discipline_name": discipline})['form_educ']
    return {'form_education': form_education}

@app.route('/get_titul_name', methods=['POST'])
def get_titul_name():
    discipline = request.form['discipline']
    titul_name = db.disciplines.find_one({"discipline_name": discipline})['titul_name']
    return {'titul_name': titul_name}

@app.route('/generate_document', methods=['POST'])
def generate_document():
    discipline = request.form['discipline']
    department = db.disciplines.find_one({"discipline_name": discipline})['department_name']
    authors = [request.form[key] for key in request.form if key.startswith('author')]
    authors = '\n'.join(authors)
    # authors = request.form.getlist('author')
    department_words = department.split(' ')
    first_word = department_words[0]
    if first_word == 'Департамент':
        first_word += 'а'
    elif first_word == 'Кафедра':
        first_word = first_word[:-1] + 'ы'
    elif first_word == 'Базовая' and department_words[1] == 'кафедра':
        first_word = 'Базовой'
        department_words[1] = 'кафедры'
    elif first_word == 'Академия':
        first_word = 'Академии'

    department_words[0] = first_word
    department = ' '.join(department_words)

    # Загрузка шаблона документа Word
    document = DocxTemplate('RPD_Template.docx')
    
    context = {
        'department': department,
        'name_author': authors,
        'date': 'Your Date Value'
    }

    # Render the template with the context
    document.render(context)


    # Создание объекта для записи документа в память
    output = io.BytesIO()

    # Сохранение документа во временный файл
    document.save(output)
    output.seek(0)

    # Отправка содержимого файла клиенту
    return Response(output, mimetype='application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                    headers={'Content-Disposition': 'attachment;filename=document.docx'})



