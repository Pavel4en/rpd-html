from app import app
from flask import render_template, request
from pymongo import MongoClient
from bs4 import BeautifulSoup
from datetime import datetime


client = MongoClient("mongodb+srv://4enpavel:NdEKoRqD6xlQGHUB@planeducation.jaybzzr.mongodb.net/test?retryWrites=true&w=majority")
db = client.test

@app.route('/', methods=['GET'])
def index():    
    return render_template('index.html')

@app.route('/parse', methods=['POST'])
def parse():
    file = request.files['file']
    content = file.read()
    soup = BeautifulSoup(content, 'xml')
    # ФормаОбучения
    ''' СЛОВАРИ'''
    # ФормаОбучения
    form_education_dict = {}
    form_education = soup.find_all('ФормаОбучения')
    for forms in form_education:
        form_education_dict[forms.get('Код')] = forms.get('ФормаОбучения')
        
    # создаем словарь для хранения информации о типах часов
    hour_types = {}
    for hour_type in soup.find_all('СправочникТипыЧасов'):
        hour_types[hour_type['Код']] = hour_type['Наименование']

    # создаем словарь для хранения информации о видах работ
    work_types = {}
    for work_type in soup.find_all('СправочникВидыРабот'):
        work_types[work_type['Код']] = work_type['Название']

    # создаем словарь для хранения информации о кафедрах
    departments = {}
    for department in soup.find_all('Кафедры'):
        departments[department['Код']] = department['Название']
        
        
    '''ПОИСК'''



    plan_rows = soup.find_all('ПланыСтроки')
    plan_hours = soup.find_all('ПланыНовыеЧасы')
    plan_education = soup.find_all('ООП')
    plan_doc = soup.find_all('Документ')
    plan_titul = soup.find_all('Планы')

    code_education = plan_education[0]['Шифр']
    name_education = plan_education[0]['Название']
    name_direction = plan_education[1]['Название']
    date_aprooval = plan_education[0]['ДатаДокумента']
    date_object = datetime.strptime(date_aprooval, '%Y-%m-%dT%H:%M:%S')
    formatted_date = date_object.strftime('%d.%m.%Y')
    number_fgos = plan_education[0]['НомерДокумента']
    year_education = plan_titul[0]['ГодНачалаПодготовки']
    years_education = plan_titul[0]['УчебныйГод']
    titul_name = plan_titul[0]['Титул']
    qualification = plan_titul[0]['Квалификация']

    print(name_education)
    print(name_direction)
    print(formatted_date)
    print(number_fgos)
    print(year_education)
    print(years_education)
    print(titul_name)
    print(qualification)
    for doc in plan_doc:
        code_form_educ = doc['КодФормыОбучения']
        form_educ = form_education_dict.get(code_form_educ)
    #         print(form_educ)

    # for edu in plan_education:
    #     code_education = edu['Шифр']
    #     name_education = edu['Название']
    #     number_fgos = edu['НомерДокумента']
    #     '''если ключ 'ДатаДокумента' не найден, то переменная date_aprooval будет равна None, 
    #        и программа продолжит работу без вызова исключения. Также в этом случае переменная 
    #        formatted_date будет равна пустой строке, чтобы в случае отсутствия даты не возникала 
    #        ошибка при вызове метода .strftime().
    #     '''
    #     date_aprooval = edu.get('ДатаДокумента')
    #     if date_aprooval:
    #         date_object = datetime.strptime(date_aprooval, '%Y-%m-%dT%H:%M:%S')
    #         formatted_date = date_object.strftime('%d.%m.%Y')
    #     else:
    #         formatted_date = ''
    #         print(number_fgos)
    #         print(formatted_date)
    #     print(code_education)
    #         print(name_education)

        # Проверяем наличие дочерних тегов <ООП> внутри текущего тега <ООП>
    #     child_edu = edu.find('ООП')
    #     if child_edu:
    #         name_direction = child_edu['Название']
    # #             print(name_direction)
    #     else:
    #         pass

    # создаем словарь для хранения информации о часах и кафедре для каждой дисциплины
    data_by_discipline = {}
    for row in plan_rows:
        discipline_name = row['Дисциплина']
        discipline_code = row['Код']
        department_code = row.get('КодКафедры')
        data_by_discipline[discipline_code] = {
            'name': discipline_name,
            'department': departments.get(department_code, ''),
            'hours': []
        }

    # связываем информацию о часах с информацией о дисциплинах
    for hour in plan_hours:
        code = hour['КодОбъекта']
        work_type_code = hour['КодВидаРаботы']
        hour_type_code = hour['КодТипаЧасов']
        hours = hour['Количество']
        semester = hour['Семестр']
        course = hour['Курс']

        if code in data_by_discipline:
            discipline_name = data_by_discipline[code]['name']
            department_name = data_by_discipline[code]['department']
            hour_type_name = hour_types.get(hour_type_code, '')
            work_type_name = work_types.get(work_type_code, '')
            data_by_discipline[code]['hours'].append({
                'discipline': discipline_name,
                'work_type': work_type_name,
                'hour_type': hour_type_name,
                'hours': hours,
                'semester': semester,
                'course': course,
                'department': department_name
        })

    for code, data in data_by_discipline.items():
        
    #     for doc in plan_doc:
    #         code_form_educ = doc['КодФормыОбучения']
    #         form_educ = form_education_dict.get(code_form_educ)
    # #         print(form_educ)

    #     for edu in plan_education:
    #         code_education = edu['Шифр']
    #         name_education = edu['Название']
    #         number_fgos = edu['НомерДокумента']
    #         '''если ключ 'ДатаДокумента' не найден, то переменная date_aprooval будет равна None, 
    #            и программа продолжит работу без вызова исключения. Также в этом случае переменная 
    #            formatted_date будет равна пустой строке, чтобы в случае отсутствия даты не возникала 
    #            ошибка при вызове метода .strftime().
    #         '''
    #         date_aprooval = edu.get('ДатаДокумента')
    #         if date_aprooval:
    #             date_object = datetime.strptime(date_aprooval, '%Y-%m-%dT%H:%M:%S')
    #             formatted_date = date_object.strftime('%d.%m.%Y')
    #         else:
    #             formatted_date = ''
    # #         print(number_fgos)
    # #         print(formatted_date)
    #         print(code_education)
    # #         print(name_education)

    #         # Проверяем наличие дочерних тегов <ООП> внутри текущего тега <ООП>
    #         child_edu = edu.find('ООП')
    #         if child_edu:
    #             name_direction = child_edu['Название']
    # #             print(name_direction)
    #         else:
    #             pass
        
        print(f"Дисциплина: {data['name']}")
        print(f"Кафедра: {data['department']}")

        # ищем все компетенции для данной дисциплины
        discipline_competencies = soup.find_all('ПланыКомпетенцииДисциплины', {'КодСтроки': code})
        
        # выводим информацию о каждой компетенции
        for comp in discipline_competencies:
            competency_code = comp['КодКомпетенции']
            competency_name = soup.find('ПланыКомпетенции', {'Код': competency_code})['ШифрКомпетенции']
            competency_description = soup.find('ПланыКомпетенции', {'Код': competency_code})['Наименование']
            print(f"Компетенция: {competency_name} ({competency_description})")

        # выводим информацию о часах для данной дисциплины
        for hour_data in data['hours']:
            if int(hour_data['course']) == 1:
                semester = int(hour_data['semester'])
                if semester == 1:
                    semester = 1
                elif semester == 2:
                    semester = 2
            elif int(hour_data['course']) == 2:
                semester = int(hour_data['semester']) + 2
            elif int(hour_data['course']) == 3:
                semester = int(hour_data['semester']) + 4
            elif int(hour_data['course']) == 4:
                semester = int(hour_data['semester']) + 6
            elif int(hour_data['course']) == 5:
                semester = int(hour_data['semester']) + 8
            # затем нужно перенести данные в базу данных


    for code, data in data_by_discipline.items():
        # Создаем документ для добавления в базу данных MongoDB
    #     plan_education = soup.find_all('ООП')
    #     for edu in plan_education:
    #         if edu['Код'] == code:
    #             code_education = edu['Шифр']
    #             break
    #         else:
    #             # Обработка случая, когда ООП с кодом code не найдено
    #             pass
        document = {
                'name_education': name_education,
                'name_direction': name_direction,
                'code_education': code_education,
                'year_education': year_education,
                'years_education': years_education,
                'titul_name': titul_name,
                'qualification': qualification,
                'form_educ': form_educ,
                'date_approoval': formatted_date,
                'number_fgos': number_fgos,
                'discipline_code': code,
                'discipline_name': data['name'],
                'department_name': data['department'],
                'competencies' : [],  # Список компетенций
                'work_hours': []  
        }

        # Ищем все компетенции для данной дисциплины
        discipline_competencies = soup.find_all('ПланыКомпетенцииДисциплины', {'КодСтроки': code})

        # Добавляем информацию о каждой компетенции в документ
        for comp in discipline_competencies:
            competency_code = comp['КодКомпетенции']
            competency_name = soup.find('ПланыКомпетенции', {'Код': competency_code})['ШифрКомпетенции']
            competency_description = soup.find('ПланыКомпетенции', {'Код': competency_code})['Наименование']
            competency_document = {
                'competency_code': competency_code,
                'competency_name': competency_name,
                'competency_description': competency_description
            }
            document['competencies'].append(competency_document)



        for hour_data in data['hours']:
            # Создаем документ для хранения типа работ и часов
            work_doc = {
                'work_type': hour_data['work_type'],
                'hours': hour_data['hours']
            }
            # Добавляем документ с типом работ и часами в список work_hours
            document['work_hours'].append(work_doc)
        # Добавляем документ в коллекцию 'disciplines'
        db.disciplines.insert_one(document)
    return 'Parsing complete!'
